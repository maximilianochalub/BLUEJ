Translation to dutch of the bluej user interface
Date: jan 2012
Author: Kris Coolsaet, Universiteit Gent, België (kris.coolsaet@UGent.be)

Made for version 3.0.6 of BlueJ

Adapted from an earlier version by
   Peter van Diepen, Stedelijk Dalton College Alkmaar, The Netherlands
Still not perfect, especially for those features of BlueJ that are
less commonly used 

Dutch terminology conforms to that used in the book:
   Programmeren in Java met BlueJ, vijfde editie,
   David J. Barnes, Michael Kölling,
   Pearson Education


