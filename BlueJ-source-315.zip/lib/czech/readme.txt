--------------------------------------------------------------------
Soubor je ulozen v kodovani UTF-8.
Kontrola kodovani: Příliš žluťoučký kůň úpěl ďábelské ódy.
--------------------------------------------------------------------

Česká lokalizace pro BlueJ 3.0.5
================================

Lokalizace pouziva kodovani UTF-8

Verze 3.0.51 ze dne 25.7.2011.

Lokalizaci vytvořili Petr Škoda a Rudolf Pecinovský.


Aktualizace a další informace získáte na adrese:

  http://vyuka.pecinovsky.cz/bluej_config/index.html

případně na mailu

  rudolf@pecinovsky.cz
